//----------------------------------------------------------
/* Game.h
 *
 * 04/17/10
 *
 * Zeb Fross
 *
 * A Checkers game.
 */
//----------------------------------------------------------

#ifndef _GAME_H_
#define _GAME_H_

#include <string>
#include <vector>
using std::vector;
#include <windows.h>

class Game
{
public:
	// create a new game of checkers
	Game( HANDLE );

	// draw gameboard and pieces in their current
	// positions
	void draw( );

	// returns true if player wants to quit game
	bool isQuit() const;

	// returns true if game is over
	bool gameIsOver() const;

	// allow player 1 to take a turn
	void movePlayer1();

	// allow player 2 to take a turn
	void movePlayer2();

private:
	// disable copy constructor
	Game( const Game & );

	// disable equals operator
	Game & operator=( const Game & );

	// moves selector to desired position
	char moveSelector();

	// moves checkers
	bool p1case1();
	bool p1case3();
	bool p1case7();
	bool p1case9();
	bool p2case1();
	bool p2case3();
	bool p2case7();
	bool p2case9();

	// move generic
	bool moveGeneric( vector<int>&, vector<int>&, int, int );

	// checks for a remaining valid move
	bool isValidMove( vector<int>&, vector<int>&, int, int );

	// is piece in bounds moving this way?
	bool inBounds( int, int );

	// checks if a player can jump
	bool canJump( vector<int>, vector<int>, int );

	// check win
	bool won();

	// writes characters to output stream
	void write( const char * );

	// writes single character to output stream
	void write( char );

	// clears entire screen
	void clearScreen();

private:
	bool gameOver;
	bool quit;
	bool jumping;
	vector<int> p1; // positions of player 1's checkers
	vector<int> p2; // positions of player 2's checkers
	int ySqr; // position of the piece selector
	HANDLE out;
	std::string player;
};

#endif // _GAME_H_

//----------------------------------------------------------
