//----------------------------------------------------------
/* main.cpp
 *
 * 04/16/10
 *
 * Zeb Fross
 *
 * A Checkers game driver.
 */
//----------------------------------------------------------

#include <conio.h>

#include <dos.h>

#include <fstream>
using std::ifstream;

#include "Game.h"

#include <iostream>
using std::cin;

#include <string>
using std::string;

#include <windows.h>

//------------------------------------------------------------

// writes characters to output stream
void write( const char * );

// returns a character, representing the user's selection:
//		D - directions
//		A - about us
//		Q - quit
//		N - new game
char getWelcomeInput( void );

// writes the contents of the given file to output stream
void displayFile( const char * );

// asks user if they are sure they want to quit and returns
// response
bool confirmQuit();

// creates and draws a new checkers game
void newGame();

// waits for user input before returning
void waitToContinue();

// writes "Congrats!" to output stream in a dramatic fashion
void writeCongrats();

// clear screen
void clearScreen();

//------------------------------------------------------------

const string WELCOME("welcome.txt");
const string DIRECTIONS("directions.txt");
const string ABOUT("aboutUs.txt");

HANDLE out = GetStdHandle( STD_OUTPUT_HANDLE );

int main( int n, char **args )
{
	char selection;
	bool quit = false;

	while (!quit) {
		displayFile(WELCOME.c_str());
		selection = getWelcomeInput();
		selection = toupper(selection);

		if (selection == 'D') {
			displayFile(DIRECTIONS.c_str());
			waitToContinue();
		} else if (selection == 'A') {
			displayFile(ABOUT.c_str());
			waitToContinue();
		} else if (selection == 'Q')
			quit = confirmQuit();
		else
			newGame();
	}

	return 0;
}

//----------------------------------------------------------

char getWelcomeInput()
{
	write("\t\t\t[N]ew Game\n");
	write("\t\t\t[D]irections\n");
	write("\t\t\t[A]bout Us\n");
	write("\t\t\t[Q]uit\n\n");

	return _getch();
}

//----------------------------------------------------------

void displayFile( const char * file)
{
	string temp;

	clearScreen();
	ifstream fin(file);

	std::getline( fin, temp );
	while ( fin ) {
		write(temp.c_str());
		write("\n");
		std::getline( fin, temp );
	}
}

//----------------------------------------------------------

bool confirmQuit()
{
	write("Are you sure you want to quit? (y/n) ");

	if (toupper(_getch()) == 'Y') {
		write("\n");
		return true;
	}
	write("\n");
	return false;
}

//----------------------------------------------------------

void newGame()
{
	Game game( out );

	clearScreen();
	game.draw( );

	while (!game.isQuit() && !game.gameIsOver()) {
		game.movePlayer1();
		if (!game.isQuit() && !game.gameIsOver())
			game.movePlayer2();
	}

	if (game.gameIsOver()) {
		clearScreen();
		writeCongrats();
	}
}

//----------------------------------------------------------

void waitToContinue()
{
	write( "Press any key to continue" );
	_getch();
}

//----------------------------------------------------------

void writeCongrats()
{
	write( "\n\n\t" );
	write( "C" ); Sleep(250);
	write( "O" ); Sleep(250);
	write( "N" ); Sleep(250);
	write( "G" ); Sleep(250);
	write( "R" ); Sleep(250);
	write( "A" ); Sleep(250);
	write( "T" ); Sleep(250);
	write( "S" ); Sleep(250);
	write( "!" ); Sleep(250);
	write( "!" ); Sleep(250);
	write( "!" );
	write( "\n\n" );
	waitToContinue();
}

//----------------------------------------------------------

void clearScreen()
{
	COORD coordScreen = { 0, 0 };    /* here's where we'll home the
                                        cursor */
    BOOL bSuccess;
    DWORD cCharsWritten;
    CONSOLE_SCREEN_BUFFER_INFO csbi; /* to get buffer info */
    DWORD dwConSize;                 /* number of character cells in
                                        the current buffer */

    /* get the number of character cells in the current buffer */

    bSuccess = GetConsoleScreenBufferInfo( out, &csbi );
    dwConSize = csbi.dwSize.X * csbi.dwSize.Y;

    /* fill the entire screen with blanks */

    bSuccess = FillConsoleOutputCharacter( out, (TCHAR) ' ',
       dwConSize, coordScreen, &cCharsWritten );

    /* get the current text attribute */

    bSuccess = GetConsoleScreenBufferInfo( out, &csbi );

    /* now set the buffer's attributes accordingly */

    bSuccess = FillConsoleOutputAttribute( out, csbi.wAttributes,
       dwConSize, coordScreen, &cCharsWritten );

    /* put the cursor at (0, 0) */

    bSuccess = SetConsoleCursorPosition( out, coordScreen );
}

//----------------------------------------------------------

void write( const char * message )
{
	DWORD numChars = 0;
	// (HANDLE, pointer to message, number of chars to write,
	// address of long to count number of chars written, NULL)
	WriteConsoleA(out, static_cast<const void *>(message),
		strlen(message),
		&numChars, NULL);
}

//------------------------------------------------------------
