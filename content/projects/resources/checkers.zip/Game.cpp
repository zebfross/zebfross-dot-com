//----------------------------------------------------------
/* main.cpp
 *
 * 04/16/10
 *
 * Zeb Fross
 *
 * Implements Game class from Game.h
 */
//----------------------------------------------------------

#include "Game.h"
#include <conio.h>
#include <iostream>
using std::cin;
#include <string>
using std::string;
#include <vector>
using std::vector;
#include <windows.h>

//----------------------------------------------------------

Game::Game( HANDLE o ) :	gameOver(false), quit(false),
							jumping(false), ySqr(43), out(o),
							player("Player 1")
{
	// fill first three rows for player2
	for (int j(0); j < 3; ++j) {
		for (int i(0); i < 8; ++i) {
			int tmp = (i % 2 == j % 2) ? 1 : 0;
			p2.push_back(tmp);
		}
	}
	// fill initially empty rows for both players
	for (int i(0); i < 40; ++i)
		p1.push_back(0), p2.push_back(0);
	// fill last three rows for player1
	for (int j(0); j < 3; ++j) {
		for (int i(0); i < 8; ++i) {
			int tmp = (i % 2 == j % 2) ? 0 : 1;
			p1.push_back(tmp);
		}
	}
}

//----------------------------------------------------------

void Game::draw( )
{
	// initialize resources
	char TLCorner(static_cast<char>(201)),
		 TRCorner(static_cast<char>(187)),
		 BLCorner(static_cast<char>(200)),
		 BRCorner(static_cast<char>(188));

	char LSide(static_cast<char>(204)),
		 RSide(static_cast<char>(185)),
		 TSide(static_cast<char>(203)),
		 BSide(static_cast<char>(202));

	char HBar(static_cast<char>(205)),
		 VBar(static_cast<char>(186));

	char TBeam(static_cast<char>(206));
	// the top edge of the board
	char top[] = {TLCorner, HBar, HBar, HBar, TSide, HBar, HBar, HBar, TSide,
				  HBar, HBar, HBar, TSide, HBar, HBar, HBar, TSide,
				  HBar, HBar, HBar, TSide, HBar, HBar, HBar, TSide,
				  HBar, HBar, HBar, TSide, HBar, HBar, HBar, TRCorner, '\0'};
	// horizontal lines in the middle of the board
	char mid[] = {LSide, HBar, HBar, HBar, TBeam, HBar, HBar, HBar, TBeam,
				  HBar, HBar, HBar, TBeam, HBar, HBar, HBar, TBeam,
				  HBar, HBar, HBar, TBeam, HBar, HBar, HBar, TBeam,
				  HBar, HBar, HBar, TBeam, HBar, HBar, HBar, RSide, '\0'};
	// the bottom edge of the board
	char bot[] = {BLCorner, HBar, HBar, HBar, BSide, HBar, HBar, HBar, BSide,
				  HBar, HBar, HBar, BSide, HBar, HBar, HBar, BSide,
				  HBar, HBar, HBar, BSide, HBar, HBar, HBar, BSide,
				  HBar, HBar, HBar, BSide, HBar, HBar, HBar, BRCorner, '\0'};

	// display top edge of board
	write( player.c_str() );
	write( "\n" );
	write( top );
	write( "\n" );
	// display top five rows of board
	for (int j(0); j < 8; ++j) {
		for (int i(0); i < 8; ++i) {
			write( VBar );
			if ( (8*j)+i == ySqr ) {
				// Color square yellow because it is currently "selected"
				SetConsoleTextAttribute( out,
					BACKGROUND_GREEN |
					BACKGROUND_RED |
					BACKGROUND_INTENSITY );
			}
			// display piece if present
			if ( (i % 2) == (j % 2) ) {
				char piece(' ');
				// player 2's piece is present
				if ( p2[(8*j)+i] ) {
					piece = (p2[(8*j)+i] == 1) ? 'o' : '0';
				// player 1's piece is present
				} else if ( p1[(8*j)+i] ) {
					piece = (p1[(8*j)+i] == 1) ? 'o' : '0';
					// set text color to red and maybe bg to yellow
					if ( (8*j)+i == ySqr )
					SetConsoleTextAttribute( out,
						BACKGROUND_GREEN |
						BACKGROUND_RED |
						BACKGROUND_INTENSITY |
						FOREGROUND_RED | FOREGROUND_INTENSITY );
					else
						SetConsoleTextAttribute(out,
							FOREGROUND_RED | FOREGROUND_INTENSITY);
				}
				write( ' ' );
				write( piece );
				write( ' ' );
				// set text color to white again
				SetConsoleTextAttribute( out,
					FOREGROUND_BLUE |
					FOREGROUND_GREEN |
					FOREGROUND_RED );
			// color square white (or maybe yellow if selected)
			} else {
				if ( (8*j)+i == ySqr )
					SetConsoleTextAttribute( out,
						BACKGROUND_GREEN |
						BACKGROUND_RED |
						BACKGROUND_INTENSITY );
				else
					SetConsoleTextAttribute( out,
						BACKGROUND_BLUE |
						BACKGROUND_GREEN |
						BACKGROUND_RED );
				char tmp[] = {' ', ' ', ' ', '\0'};
				write( tmp );
			}
			// Color bg black again and text white
			SetConsoleTextAttribute( out,
				FOREGROUND_BLUE |
				FOREGROUND_GREEN |
				FOREGROUND_RED );
		}
		write( VBar );
		write( '\n' );
		if (j < 7) // if not bottom edge
			write( mid ), write( '\n' );
	}
	// display bottom edge, and you're dp1!
	write( bot );
	write( "\n" );
	// display directions
	write( "'q' to quit\nnum-pad moves checkers\n" );
}

//----------------------------------------------------------

bool Game::isQuit() const {
	return quit;
}

bool Game::gameIsOver() const {
	return gameOver;
}

//----------------------------------------------------------

void Game::movePlayer1()
{
	bool moved = false;
	player = "Player 1";
	while (!moved) {
		char move;
		if (!jumping) { // allow multiple jumps
			move = moveSelector();
		} else {
			clearScreen();
			draw( );
			move = _getch();
		}
		if ( p1[ySqr] ) { // if player 1's piece
			switch (move) {
			case '1':
				moved = moveGeneric( p1, p2, 2, 7 );
				break;
			case '3':
				moved = moveGeneric( p1, p2, 2, 9 );
				break;
			case '7':
				moved = moveGeneric( p1, p2, 1, -9 );
				break;
			case '9':
				moved = moveGeneric( p1, p2, 1, -7 );
				break;
			default:
				break;
			}
		}
		if (toupper(move) == 'Q') {
			quit = true;
			moved = true;
		}
	}
	player = "Player 2";
	clearScreen();
	draw( );
}

//----------------------------------------------------------

void Game::movePlayer2()
{
	bool moved = false;
	player = "Player 2";
	while (!moved) {
		char move;
		if (!jumping) { // allow multiple jumps
			move = moveSelector();
		} else {
			clearScreen();
			draw();
			move = _getch();
		}
		if ( p2[ySqr] ) { // if player 1's piece
			switch (move) {
			case '1':
				moved = moveGeneric( p2, p1, 1, 7 );
				break;
			case '3':
				moved = moveGeneric( p2, p1, 1, 9 );
				break;
			case '7':
				moved = moveGeneric( p2, p1, 2, -9 );
				break;
			case '9':
				moved = moveGeneric( p2, p1, 2, -7 );
				break;
			default:
				break;
			}
		}
		if (move == 'q') {
			quit = true;
			moved = true;
		}
	}
	player = "Player 1";
	clearScreen();
	draw();
}

//----------------------------------------------------------

bool Game::moveGeneric( vector<int>& pla, vector<int>& opp,
					    int piece, int dis )
{
	if (!inBounds(ySqr, dis))
		return false;
	// is valid piece and in bounds and not occupied
	// by own piece
	if ( pla[ySqr] >= piece && ySqr+dis <= 63 &&
		 ySqr+dis >= 0 && !pla[ySqr+dis]) {
		// enter empty space -- cannot do this if jumping
		if ( !opp[ySqr+dis] ) {
			if (!canJump( pla, opp, dis )) {
				std::swap( pla[ySqr], pla[ySqr+dis] );
				if (ySqr+dis < 8 || ySqr+dis > 55)
					pla[ySqr+dis] = 2; // king me!
				return true;
			} else { // error! must jump!
				player = player.substr( 0, 8 ) + 
					" - Must Jump!";
				clearScreen();
				draw();
			}
		// jump oppp1nt's piece
		} else if ( ySqr+(dis*2) <= 63 && ySqr+(dis*2) >= 0
			&& !pla[ySqr+(dis*2)] && !opp[ySqr+(dis*2)]
			&& inBounds(ySqr+(dis), dis)) {
				std::swap( pla[ySqr], pla[ySqr+(dis*2)] );
				opp[ySqr+dis] = 0;
				ySqr += dis*2;
				if (ySqr < 8 || ySqr > 55)
					pla[ySqr] = 2; // king me!
				jumping = isValidMove( pla, opp, piece, dis );
				gameOver = won();
				return !jumping; // not jumping = done moving
		}
	} else {
		std::cout << static_cast<char>(7);
	}
	return false;
}

//----------------------------------------------------------

bool Game::isValidMove( vector<int>& pla, vector<int>& opp,
					    int piece, int dis )
{
	int s = (dis < 0) ? -1 : 1;
	int sqr;
	for (int i(0); i < 2; ++i) {
		sqr = ySqr+(14*s);
		// can jump to top-right or maybe bottom-left
		if ( sqr <= 63 && sqr >= 0
			&& !pla[sqr] && !opp[sqr] &&
			opp[ySqr+(7*s)] && inBounds(ySqr+(7*s), 7*s))
				return true;
		sqr = ySqr+(18*s);
		// can jump to top-left or maybe bottom-right
		if ( sqr <= 63 && sqr >= 0
			&& !pla[sqr] && !opp[sqr] &&
			opp[ySqr+(9*s)] && inBounds(ySqr+(9*s), 9*s))
				return true;
		// if not a king, don't test other cases
		if (piece < 2)
			break;
		s *= -1;
	}
	return false;
}

//----------------------------------------------------------

bool Game::inBounds( int pos, int dis )
{
	// selector on left-edge of board
	if (pos % 8 == 0) {
		if (dis < 0 && dis < -7)
			return false;
		if (dis > 0 && dis < 9)
			return false;
	} else if (pos % 8 == 7) {
		if (dis < 0 && dis > -9)
			return false;
		if (dis > 0 && dis > 7)
			return false;
	}
	return true;
}

//----------------------------------------------------------

bool Game::canJump( vector<int> pla, vector<int> opp, int dis )
{
	int tmp = ySqr;
	for (int i(0); i < pla.size(); ++i) {
		if ( pla[i] > 0 ) {
			ySqr = i;
			if (isValidMove( pla, opp, pla[i], dis )) {
				ySqr = tmp;
				return true;
			}
		}
	}
	ySqr = tmp;
	return false;
}

//----------------------------------------------------------

bool Game::won()
{
	bool one = false;
	bool two = false;
	for (int i(0); i < 64; ++i) {
		one = one || p1[i] > 0;
		two = two || p2[i] > 0;
	}
	return !(one && two); // at least one player wiped out
}

//----------------------------------------------------------

char Game::moveSelector( )
{
	int upDown = 9;
	bool moved = false;
	while (!moved) {
		char move = _getch();
		switch (move) {
		case '2':
			if (ySqr+8 <= 63) { // move selector down
				if (ySqr % 8 == 7) // on right edge
					ySqr += 7;
				else if (ySqr % 8 == 0) // on left edge
					ySqr += 9;
				else
					ySqr += (upDown == 9) ? 9 : 7;
				upDown = (upDown == 9) ? 7 : 9;
				clearScreen();
				draw();
			}
			break;
		case '4':
			if( ySqr > 0 ) { // move selector left
				if (ySqr % 8 == 1)
					ySqr -= 3;
				else if (ySqr % 8 == 0)
					ySqr -= 1;
				else
					ySqr -= 2;
				clearScreen();
				draw();
			}
			break;
		case '6':
			if( ySqr < 63 ) { // move selector right
				if (ySqr % 8 == 6)
					ySqr += 3;
				else if (ySqr % 8 == 7)
					ySqr += 1;
				else
					ySqr += 2;
				clearScreen();
				draw();
			}
			break;
		case '8':
			if (ySqr-8 >= 0) { // move selector up
				if (ySqr % 8 == 7) // on right edge
					ySqr -= 9;
				else if (ySqr % 8 == 0) // on left edge
					ySqr -= 7;
				else
					ySqr -= (upDown == 9) ? 7 : 9;
				upDown = (upDown == 9) ? 7 : 9;
				clearScreen();
				draw();
			}
			break;
		default:
			moved = true;
			return move;
			break;
		}
	}
	return 'q'; // this should never happen
}

//----------------------------------------------------------

void Game::write( const char * message )
{
	DWORD numChars = 0;
	// (HANDLE, pointer to message, number of chars to write,
	// address of long to count number of chars written, NULL)
	WriteConsoleA(out, static_cast<const void *>(message),
		strlen(message),
		&numChars, NULL);
}

//----------------------------------------------------------

void Game::write( const char message )
{
	char tmp[] = {message, '\0'};
	DWORD numChars = 0;
	// (HANDLE, pointer to message, number of chars to write,
	// address of long to count number of chars written, NULL)
	WriteConsoleA(out, static_cast<const void *>(tmp),
		strlen(tmp),
		&numChars, NULL);
}

//----------------------------------------------------------

void Game::clearScreen()
{
	COORD coordScreen = { 0, 0 };    /* here's where we'll home the
                                        cursor */
    BOOL bSuccess;
    DWORD cCharsWritten;
    CONSOLE_SCREEN_BUFFER_INFO csbi; /* to get buffer info */
    DWORD dwConSize;                 /* number of character cells in
                                        the current buffer */

    /* get the number of character cells in the current buffer */

    bSuccess = GetConsoleScreenBufferInfo( out, &csbi );
    dwConSize = csbi.dwSize.X * csbi.dwSize.Y;

    /* fill the entire screen with blanks */

    bSuccess = FillConsoleOutputCharacter( out, (TCHAR) ' ',
       dwConSize, coordScreen, &cCharsWritten );

    /* get the current text attribute */

    bSuccess = GetConsoleScreenBufferInfo( out, &csbi );

    /* now set the buffer's attributes accordingly */

    bSuccess = FillConsoleOutputAttribute( out, csbi.wAttributes,
       dwConSize, coordScreen, &cCharsWritten );

    /* put the cursor at (0, 0) */

    bSuccess = SetConsoleCursorPosition( out, coordScreen );
}

//----------------------------------------------------------
